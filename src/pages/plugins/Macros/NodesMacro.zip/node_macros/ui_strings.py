##########################################################################
# ADOBE CONFIDENTIAL
# ___________________
#  Copyright 2010-2024 Adobe
#  All Rights Reserved.
# * NOTICE:  Adobe permits you to use, modify, and distribute this file in
# accordance with the terms of the Adobe license agreement accompanying it.
# If you have received this file from a source other than Adobe,
# then your use, modification, or distribution of it requires the prior
# written permission of Adobe.
##########################################################################

from PySide6.QtCore import QCoreApplication

# UI

# Toolbar buttons
BUTTON_TOOLTIP_SAVE = QCoreApplication.translate(
    "NodeMacros", "Save selected nodes as a macro")
BUTTON_TOOLTIP_EDIT = QCoreApplication.translate(
    "NodeMacros", "Edit macros")

# Generic dialogs
INFO_DIALOG_TITLE = QCoreApplication.translate(
    "NodeMacros", "Node macros")
WARNING_SAVE_NO_SELECTION = QCoreApplication.translate(
    "NodeMacros", "Please select at least one node or graph item.")
WARNING_MACRO_NOT_SAVED = QCoreApplication.translate(
    "NodeMacros", "The macro could not be saved.<br>Check the Console for more details.")
WARNING_MACRO_NOT_PLACED = QCoreApplication.translate(
    "NodeMacros", "The macro could not be placed.<br>Check the Console for more details.")
WARNING_MACROS_NOT_LOADED = QCoreApplication.translate(
    "NodeMacros", "The macros could not be loaded.<br>Check the Console for more details.")
WARNING_MACRO_NOT_LOADED_FROM_CATALOGUE = QCoreApplication.translate(
    "NodeMacros", "A macro could not be loaded from the catalogue.<br>Check the Console for more details.")
WARNING_MACRO_NOT_EDITED = QCoreApplication.translate(
    "NodeMacros", "The macro could not be edited.<br>Check the Console for more details.")

# 'Edit macro' dialog
EDIT_DIALOG_TITLE = QCoreApplication.translate(
    "NodeMacros", "Edit macros")
EDIT_DIALOG_CLOSE = QCoreApplication.translate(
    "NodeMacros", "CLOSE")
EDIT_DIALOG_MOVE_UP_TOOLTIP = QCoreApplication.translate(
    "NodeMacros", "Move macro up")
EDIT_DIALOG_MOVE_DOWN_TOOLTIP = QCoreApplication.translate(
    "NodeMacros", "Move macro down")
EDIT_DIALOG_DELETE_TOOLTIP = QCoreApplication.translate(
    "NodeMacros", "Delete macro")
EDIT_WARNING_EXISTS = QCoreApplication.translate(
    "NodeMacros", "The macro name must be unique.")
EDIT_WARNING_EMPTY = QCoreApplication.translate(
    "NodeMacros", "The macro name cannot be empty or whitespace.")

# 'Save macro' dialog
SAVE_DIALOG_TITLE = QCoreApplication.translate(
    "NodeMacros", "Save macro")
SAVE_FIELD_NAME = QCoreApplication.translate(
    "NodeMacros", "Place node macro")
SAVE_FIELD_DESCRIPTION = QCoreApplication.translate(
    "NodeMacros", "Place node macro")
SAVE_DIALOG_OK = QCoreApplication.translate(
    "NodeMacros", "OK")
SAVE_DIALOG_CANCEL = QCoreApplication.translate(
    "NodeMacros", "CANCEL")
SAVE_WARNING_EXISTS = QCoreApplication.translate(
    "NodeMacros", "The macro name must be unique.")
SAVE_WARNING_EMPTY = QCoreApplication.translate(
    "NodeMacros", "The macro name cannot be empty or whitespace.")

# History entries
HISTORY_ENTRY_LABEL_LOAD = QCoreApplication.translate(
    "NodeMacros", "Load node macros")
HISTORY_ENTRY_LABEL_EDIT = QCoreApplication.translate(
    "NodeMacros", "Edit macro")
HISTORY_ENTRY_LABEL_PLACE = QCoreApplication.translate(
    "NodeMacros", "Place node macro")

# LOGS

# Info
INFO_INIT_ACTIONS_REGISTERED = QCoreApplication.translate(
    "NodeMacros", "Registered 'Node macros' actions...")
INFO_INIT_ACTIONS_UNREGISTERED = QCoreApplication.translate(
    "NodeMacros", "Unregistered 'Node macros' actions...")
INFO_INIT_COLLECTION_FILEPATHS = QCoreApplication.translate(
    "NodeMacros", "Macros collections located: {}")
INFO_LOADED_GRAPH = QCoreApplication.translate(
    "NodeMacros", "Loaded graph '{}' from package at: {}")
INFO_PLACED_MACRO = QCoreApplication.translate(
    "NodeMacros", "Placed macro '{}'")
INFO_FOUND_QGRAPHICSVIEW = QCoreApplication.translate(
    "NodeMacros", "Found QGraphicsView for Graph View #{}: {}")
INFO_TOOLBAR_BUTTONS_CREATED = QCoreApplication.translate(
    "NodeMacros", "Macro toolbar Add/Edit buttons created")
INFO_MACRO_SAVED = QCoreApplication.translate(
    "NodeMacros", "New macro {} saved at: {}")

# Warnings
WARNING_UNSUPPORTED_GRAPH_TYPE = QCoreApplication.translate(
    "NodeMacros", "This graph type does not support node macros.")

# Errors
ERROR_SAVE_MACRO_FAIL = QCoreApplication.translate(
    "NodeMacros", "Saving macro package failed: {} {}")
ERROR_LOAD_MACROS_FAIL = QCoreApplication.translate(
    "NodeMacros", "Failed to initialize toolbar macro buttons: {} {}")
ERROR_INIT_MACRO_FAIL = QCoreApplication.translate(
    "NodeMacros", "Failed to add macro from catalogue at '{}': {} {}")
ERROR_COPY_TO_GRAPH_FAIL = QCoreApplication.translate(
    "NodeMacros", "Copying selection to graph failed: {} {}")
ERROR_PLACED_MACRO_FAIL = QCoreApplication.translate(
    "NodeMacros", "Placing macro failed: {} {}")
ERROR_NOT_FOUND_QGRAPHICSVIEW = QCoreApplication.translate(
    "NodeMacros", "No QGraphicsView found for Graph View #{}")
ERROR_VIEWPORT_TRANSFORM_UNAVAILABLE = QCoreApplication.translate(
    "NodeMacros", "Cannot access viewport transform: {} {}")
ERROR_EDIT_MACRO_FAIL = QCoreApplication.translate(
    "NodeMacros", "Failed to edit macro '{}': {} {}")

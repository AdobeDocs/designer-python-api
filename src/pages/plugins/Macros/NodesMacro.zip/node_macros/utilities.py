##########################################################################
# ADOBE CONFIDENTIAL
# ___________________
#  Copyright 2010-2024 Adobe
#  All Rights Reserved.
# * NOTICE:  Adobe permits you to use, modify, and distribute this file in
# accordance with the terms of the Adobe license agreement accompanying it.
# If you have received this file from a source other than Adobe,
# then your use, modification, or distribution of it requires the prior
# written permission of Adobe.
##########################################################################

import os
from os import path

from PySide6 import QtGui
from PySide6.QtWidgets import QGraphicsView

import sd
from sd.api.sdpackagemgr import SDPackageMgr
from sd.api.apiexception import APIException
from sd.api.sdconnection import SDConnection
from sd.api.sdproperty import SDProperty, SDPropertyCategory
from sd.api.sdnode import SDNode
from sd.api.sdgraph import SDGraph
from sd.api.sdgraphobject import SDGraphObject
from sd.api import sdgraphobjectframe, sdgraphobjectcomment, sdgraphobjectpin
from sd.api.sdarray import SDArray
from sd.api.sdbasetypes import float2, float4
from sd.api.sdvaluestring import SDValueString
from sd.api.sbs.sdsbscompnode import SDSBSCompNode
from sd.api.sbs.sdsbsfunctiongraph import SDSBSFunctionGraph
from sd.ui.graphgrid import GraphGrid

from .ui_strings import *
import logging

GRID_SIZE = GraphGrid.sGetSecondLevelSize()

# Initialise logger
LOGGER = logging.getLogger("NodeMacros")
LOGGER.addHandler(sd.getContext().createRuntimeLogHandler())
LOGGER.propagate = False
LOGGER.setLevel(logging.DEBUG)


def get_last_nodes_in_stream(graph_selected_nodes: SDArray[SDNode]) -> list[SDNode]:
    """
    Takes a list of nodes and filters it to return the nodes in that list
    which outputs are not connected to any other node from that list.
    :param graph_selected_nodes: The input list of nodes' IDs.
    :return: The filtered list of nodes.
    """

    selected_nodes_id = [node.getIdentifier() for node in graph_selected_nodes]
    last_nodes = []

    for node in graph_selected_nodes:
        is_last_node = True
        for prop in node.getProperties(SDPropertyCategory.Output):
            for connection in node.getPropertyConnections(prop):
                if connection.getInputPropertyNode().getIdentifier() in selected_nodes_id:
                    is_last_node = False
        if is_last_node:
            last_nodes.append(node)

    return last_nodes


def copy_node_to_graph(node: SDNode, target_graph: SDGraph) -> SDNode:
    """
    Creates a copy of an input node in a target graph and then returns that copy.
    :param node: The input node.
    :param target_graph: The target graph.
    :return: The copied node in the target graph.
    """
    # TODO Support Dot node's names / NOT SUPPORTED IN API

    # Create node copy in target graph
    node_def_id = node.getDefinition().getId()
    if "instance" in node_def_id:
        node_copy = target_graph.newInstanceNode(node.getReferencedResource())
    else:
        node_copy = target_graph.newNode(node_def_id)

    # Copy input properties
    # Disabling nodes is not supported
    node_input_props = node.getProperties(SDPropertyCategory.Input)

    for prop in node_input_props:
        node_copy_prop = node_copy.getPropertyFromId(prop.getId(), SDPropertyCategory.Input)
        if not prop.isConnectable():
            prop_graph = node.getPropertyGraph(prop)
            if isinstance(node, SDSBSCompNode):
                if prop_graph:
                    copy_property_graph(prop=prop, prop_graph=prop_graph, target_node=node_copy)
                # Copy property inheritance method
                try:
                    node_copy.setPropertyInheritanceMethod(node_copy_prop, node.getPropertyInheritanceMethod(prop))
                except APIException:
                    pass

            # Copy property value
            if not prop_graph:
                node_copy.setPropertyValue(node_copy_prop, node.getPropertyValue(prop))

    return node_copy


def copy_upstream_nodes_in_stream(
    source_node: SDNode,
    target_node: SDNode,
    nodes_id_in_stream: list[str],
    target_graph: SDGraph,
    copied_nodes: dict
) -> None:
    """
    For any source node in a stream and its target copy in a target graph,
    recursively copies upstream nodes of the source as upstream nodes
    of the target in the target graph.
    :param source_node: The last node in the selected stream from the source graph.
    :param target_node: The copy of the last node in the target graph.
    :param nodes_id_in_stream: The list of selected nodes' IDs.
    :param target_graph: The target graph.
    :param copied_nodes: A dictionary of source/copy node ID pairs.
    """
    # TODO Collect connections on upstream traversal then create them using downstream traversal

    source_node_input_props = source_node.getProperties(SDPropertyCategory.Input)
    source_node_pos = source_node.getPosition()
    target_node_pos = target_node.getPosition()

    for prop in source_node_input_props:
        if prop.isConnectable():

            # Go through every input connection
            prop_connections: SDArray[SDConnection] = source_node.getPropertyConnections(prop)
            for connection in prop_connections:
                upstream_node: SDNode = connection.getInputPropertyNode()
                upstream_node_id = upstream_node.getIdentifier()
                if upstream_node_id in nodes_id_in_stream:

                    # Check if upstream node was already copied
                    # by a previous stream branch before creating a copy
                    if upstream_node_id not in copied_nodes:
                        upstream_node_copy = copy_node_to_graph(upstream_node, target_graph)
                        copied_nodes[upstream_node_id] = upstream_node_copy.getIdentifier()
                        upstream_node_copy.setPosition(transfer_relative_position(
                            reference_pos=source_node_pos,
                            source_pos=upstream_node.getPosition(),
                            reference_target_pos=target_node_pos
                        ))
                    else:
                        upstream_node_copy = target_graph.getNodeFromId(copied_nodes[upstream_node_id])

                    # Copy upstream node connection
                    upstream_node_copy.newPropertyConnectionFromId(
                        connection.getInputProperty().getId(),
                        target_node,
                        connection.getOutputProperty().getId()
                    )

                    # Recurse into upstream node
                    copy_upstream_nodes_in_stream(
                        source_node=upstream_node,
                        target_node=upstream_node_copy,
                        nodes_id_in_stream=nodes_id_in_stream,
                        target_graph=target_graph,
                        copied_nodes=copied_nodes
                    )


def copy_selection_to_graph(
        selected_nodes: SDArray[SDNode],
        selected_helpers: SDArray[SDGraphObject],
        output_nodes_id: list[str],
        target_graph: SDGraph,
        target_graph_viewport: QGraphicsView = None,
        use_viewport: bool = False
) -> None:
    """
    Copies all input node streams to a specified target graph.
    :param selected_nodes: The list of identifiers for nodes in the streams which should be copied.
    :param selected_helpers: The list of selected graph helpers.
    :param output_nodes_id: The list of identifiers of the graph's output nodes.
    :param target_graph: The target graph where nodes should be copied.
    :param target_graph_viewport: The QGraphicsView for the target graph's Graph View.
    :param use_viewport: Place outputs using current graph view centre (True) or source graph positions as is (False).
    """

    if selected_nodes:
        last_nodes = get_last_nodes_in_stream(selected_nodes)
        copied_nodes: dict = {}

        # Use the macro's Bbox center as reference position
        last_node_reference_position: float2 = get_bbox_center_position(absolute_selection_bbox(
            selected_nodes=selected_nodes,
            selected_helpers=selected_helpers
        ))

        reference_helper_position: float2 = last_node_reference_position

        # Select the target position for the reference position
        position_origin = (
            get_graph_view_center_position(target_graph_viewport)
            if use_viewport
            else last_node_reference_position
        )

        # Process every last nodes
        for last_node in last_nodes:
            last_node_copy = copy_node_to_graph(node=last_node, target_graph=target_graph)

            # Place last node relatively to reference last node
            last_node_pos = transfer_relative_position(
                reference_pos=last_node_reference_position,
                source_pos=last_node.getPosition(),
                reference_target_pos=position_origin
            )

            last_node_pos = float2(
                last_node_pos.x - last_node_pos.x % GRID_SIZE - (GRID_SIZE / 2),
                last_node_pos.y - last_node_pos.y % GRID_SIZE - (GRID_SIZE / 2)
            )
            last_node_copy.setPosition(last_node_pos)

            # Copy upstream nodes
            selected_nodes_id = [node.getIdentifier() for node in selected_nodes]
            copy_upstream_nodes_in_stream(
                source_node=last_node,
                target_node=last_node_copy,
                nodes_id_in_stream=selected_nodes_id,
                target_graph=target_graph,
                copied_nodes=copied_nodes
            )
            if last_node.getIdentifier() in output_nodes_id:

                # Copy Output nodes' annotations
                for annotation in last_node.getProperties(SDPropertyCategory.Annotation):
                    annotation_id = annotation.getId()
                    last_node_copy.setAnnotationPropertyValueFromId(
                        annotation_id,
                        last_node.getAnnotationPropertyValueFromId(annotation_id)
                    )

                # Set output node in function graphs
                if isinstance(target_graph, SDSBSFunctionGraph):
                    target_graph.setOutputNode(last_node_copy, True)

    elif selected_helpers:
        reference_helper_position = selected_helpers[0].getPosition()
        position_origin = (
            get_graph_view_center_position(target_graph_viewport)
            if use_viewport
            else reference_helper_position
        )
    else:
        return None

    copy_graph_helpers(
        helpers=selected_helpers,
        target_graph=target_graph,
        reference_position=position_origin,
        reference_helper_position=reference_helper_position
    )


# TODO Fix: Frames are not positioned correctly
def copy_graph_helpers(
        helpers: SDArray[SDGraphObject],
        target_graph: SDGraph,
        reference_position: float2,
        reference_helper_position: float2
):
    """
    Copies each graph helper in the provided list into a target graph.
    :param helpers: The list of graph helper objects.
    :param target_graph: The graph into which the helpers should be copied.
    :param reference_position: The position all helpers should be placed relatively to.
    :param reference_helper_position: The position of an arbitrary reference helper.
    """

    helper_copy = None

    for helper in helpers:
        # Frames
        if isinstance(helper, sdgraphobjectframe.SDGraphObjectFrame):
            helper_copy = sdgraphobjectframe.SDGraphObjectFrame.sNew(target_graph)
            helper_copy.setTitle(helper.getTitle())
            helper_copy.setColor(helper.getColor())
            helper_copy.setSize(helper.getSize())
        # Comments
        # TODO Support parented comments --> DESIGNER-6517
        elif isinstance(helper, sdgraphobjectcomment.SDGraphObjectComment):
            helper_copy = sdgraphobjectcomment.SDGraphObjectComment.sNew(target_graph)
        # Pins
        elif isinstance(helper, sdgraphobjectpin.SDGraphObjectPin):
            helper_copy = sdgraphobjectpin.SDGraphObjectPin.sNew(target_graph)

        helper_copy.setPosition(transfer_relative_position(
            reference_pos=reference_helper_position,
            source_pos=helper.getPosition(),
            reference_target_pos=reference_position
        ))

        helper_copy.setDescription(helper.getDescription())


def copy_property_graph(prop: SDProperty, prop_graph: SDSBSFunctionGraph, target_node: SDNode) -> None:

    prop_graph_copy = target_node.newPropertyGraph(
        sdProperty=target_node.getPropertyFromId(
            sdPropertyId=prop.getId(),
            sdPropertyCategory=SDPropertyCategory.Input
        ),
        sdGraphTypeId="SDSBSFunctionGraph"
    )
    helpers: SDArray[SDGraphObject] = prop_graph.getGraphObjects()
    output_node_ids: list[str] = [node.getIdentifier() for node in prop_graph.getOutputNodes()]
    copy_selection_to_graph(
        selected_nodes=prop_graph.getNodes(),
        output_nodes_id=output_node_ids,
        selected_helpers=helpers,
        target_graph=prop_graph_copy
    )


def transfer_relative_position(reference_pos: float2, source_pos: float2, reference_target_pos: float2) -> float2:
    """
    Computes the relative position of a source position to a reference position in a graph,
    then returns that relative position to another target reference.
    :param reference_pos: The reference position.
    :param source_pos: The source position.
    :param reference_target_pos: The reference target position.
    :return: The relative position of source to reference.
    """

    return float2(
        reference_target_pos.x + (source_pos.x - reference_pos.x),
        reference_target_pos.y + (source_pos.y - reference_pos.y)
    )


def get_graph_view_center_position(graph_viewport: QGraphicsView) -> float2:

    # Transformation matrix for current view of graph scene in viewport
    try:
        transform = graph_viewport.viewportTransform()
    except Exception as ex:
        LOGGER.error(ERROR_VIEWPORT_TRANSFORM_UNAVAILABLE.format(type(ex).__name__, ex.args))
        LOGGER.warning("Target position could not be computed, defaulting to graph origin at (0.0, 0.0)")
        return float2(0.0, 0.0)

    # QRect object for viewport
    rect = graph_viewport.rect()

    # The center of the graph view is the position of the graph scene in the top left
    # corner of the viewport, plus half the viewport's width and height, both adjusted
    # to the current scale or zoom level
    #
    # m11 = graph scene scale, or zoom level
    # m31 = x translation, or x position of graph scene at top left corner of viewport
    # m32 = y translation, or y position of graph scene at top left corner of viewport
    view_center_position_x = (-transform.m31() / transform.m11()) + (rect.width() / transform.m11() / 2)
    view_center_position_y = (-transform.m32() / transform.m11()) + (rect.height() / transform.m11() / 2)

    # Return the position as a float2 value
    LOGGER.debug(f"Graph View viewport center position: ({view_center_position_x}, {view_center_position_y})")
    return float2(view_center_position_x, view_center_position_y)


def absolute_selection_bbox(selected_nodes: SDArray[SDNode], selected_helpers: SDArray[SDGraphObject]) -> float4:

    obj_positions: list[float2] = [obj.getPosition() for obj in list(selected_nodes) + list(selected_helpers)]
    position_min: float2 = float2(min([pos.x for pos in obj_positions]), min([pos.y for pos in obj_positions]))
    position_max: float2 = float2(max([pos.x for pos in obj_positions]), max([pos.y for pos in obj_positions]))

    return float4(position_min.x, position_min.y, position_max.x, position_max.y)


def get_bbox_center_position(bbox: float4) -> float2:

    bbox_size: float2 = float2(bbox.z - bbox.x, bbox.w - bbox.y)

    return float2(bbox.x + bbox_size.x / 2, bbox.y + bbox_size.y / 2)


def sanitize_filename(filename: str) -> str:
    """
    Makes the specified filename safe for most file systems.
    :param filename: The string that should be sanitized.
    :return: The sanitized filename.
    """

    for char in filename:
        if not char.isalnum():
            filename = filename.replace(char, "_")
    filename = filename.lower()

    return filename


def edit_macro_data(pkg_mgr: SDPackageMgr, old_macro_data: dict, new_macro_data: dict) -> None:
    """
    Loads a macro package, updates its data and saves it according to the data in the specified dictionaries.\
    If a macro's name is changed, saves a new macro package and deletes the current one.
    :param pkg_mgr: The package manager for the current session.
    :param old_macro_data: The dictionary describing the current macro.
    :param new_macro_data: The dictionary describing the updated macro.
    """
    # Load macro graph
    macro_pkg = pkg_mgr.loadUserPackage(old_macro_data["filepath"])
    macro_graph = macro_pkg.getChildrenResources(isRecursive=False)[0]
    is_replaced = False

    # Edit description in existing package
    if old_macro_data["description"] != new_macro_data["description"]:
        macro_graph.setAnnotationPropertyValueFromId(
            "description",
            SDValueString.sNew(new_macro_data["description"])
        )
        pkg_mgr.savePackage(macro_pkg)

    # Edit label and identifier and save to renamed package
    if old_macro_data["name"] != new_macro_data["name"]:
        macro_graph.setIdentifier(new_macro_data["sanitized_name"])
        macro_graph.setAnnotationPropertyValueFromId(
            "label",
            SDValueString.sNew(new_macro_data["name"])
        )
        pkg_mgr.savePackageAs(macro_pkg, new_macro_data["filepath"])
        is_replaced = True

    # Edit package filepath to new macro index
    if old_macro_data["filepath"] != new_macro_data["filepath"]:
        pkg_mgr.savePackageAs(macro_pkg, new_macro_data["filepath"])
        is_replaced = True

    pkg_mgr.unloadUserPackage(macro_pkg)

    if is_replaced:
        os.remove(old_macro_data["filepath"])


def icon_factory(icon_filename: str) -> QtGui.QIcon:
    """
    Returns a QIcon for the specified image file in the 'icons' directory
    :param icon_filename: The image filename.
    :return: The generated QIcon.
    """
    return QtGui.QIcon(path.join(path.realpath(path.dirname(__file__)), "icons", icon_filename))

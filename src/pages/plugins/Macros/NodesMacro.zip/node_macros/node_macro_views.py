##########################################################################
# ADOBE CONFIDENTIAL
# ___________________
#  Copyright 2010-2024 Adobe
#  All Rights Reserved.
# * NOTICE:  Adobe permits you to use, modify, and distribute this file in
# accordance with the terms of the Adobe license agreement accompanying it.
# If you have received this file from a source other than Adobe,
# then your use, modification, or distribution of it requires the prior
# written permission of Adobe.
##########################################################################

from functools import partial
from sd.api.sdhistoryutils import SDHistoryUtils
from PySide6 import QtWidgets
from PySide6.QtWidgets import QListView, QStyledItemDelegate, QToolButton, QStyleOptionViewItem, QSizePolicy
from PySide6.QtCore import Qt, QObject, QModelIndex, QRect, QSize, QPersistentModelIndex, Signal
from PySide6.QtGui import QFontMetrics
from .ui_strings import *
from .utilities import icon_factory

ROW_HEIGHT = 30
MACRO_EDITOR_BUTTON_WIDTH = 10


class MacrosToolbarView(QListView):

    def __init__(self, parent: QtWidgets.QWidget):

        super(MacrosToolbarView, self).__init__(parent=parent)

        self.parent = parent
        self.setFlow(QListView.Flow.LeftToRight)
        self.setFixedHeight(self.parent.rect().height())
        self.setEditTriggers(self.EditTrigger.NoEditTriggers)
        self.setSelectionMode(self.SelectionMode.NoSelection)
        self.setStyleSheet(
            "border: none;"
            "background-color: transparent"
        )

    def sizeHintForIndex(self, index: QModelIndex):

        font_metrics: QFontMetrics = self.fontMetrics()
        rect: QRect = font_metrics.boundingRect(index.data(Qt.ItemDataRole.DisplayRole))

        return QSize(rect.width(), rect.height())


class MacrosEditView(QListView):

    def __init__(self, parent: QObject):

        super(MacrosEditView, self).__init__(parent=parent)

        self.parent = parent
        self.setViewMode(self.ViewMode.ListMode)
        self.setFlow(QListView.Flow.TopToBottom)
        # self.setEditTriggers(self.EditTrigger.DoubleClicked)
        self.setDragDropMode(QListView.DragDropMode.InternalMove)
        self.setDragDropOverwriteMode(False)
        self.setMovement(QListView.Movement.Snap)


class MacroEditDelegate(QStyledItemDelegate):

    # Signals
    result_signal = Signal(bool, int)

    def __init__(self):

        super(MacroEditDelegate, self).__init__()

    def sizeHint(self, option: QStyleOptionViewItem, index: QModelIndex) -> QSize:

        return QSize(option.rect.width(), ROW_HEIGHT)

    def createEditor(self, parent, option, index):

        persistent_index = QPersistentModelIndex(index)
        row = persistent_index.row()

        editor = MacroEditor(parent=parent)
        editor.setObjectName(f"macro_{row}_frame")
        editor.frame_layout.setObjectName(f"macro_{row}_layout")

        # 'MOVE MACRO' buttons
        editor.move_down_button.setObjectName(f"move_macro_{row}_down_button")
        editor.move_up_button.setObjectName(f"move_macro_{row}_up_button")
        editor.move_up_button.clicked.connect(partial(index.model().moveRowHandler, persistent_index, -1))
        editor.move_down_button.clicked.connect(partial(index.model().moveRowHandler, persistent_index, 1))
        if persistent_index.model().rowCount() < 2:
            editor.move_up_button.setEnabled(False)
            editor.move_down_button.setEnabled(False)

        # 'MACRO NAME' line edit
        editor.macro_line_edit.setObjectName(f"macro_{row}_line_edit")
        editor.macro_line_edit.setText(index.data(Qt.ItemDataRole.DisplayRole))
        # Apply renaming when changing focus or pressing 'Enter'
        editor.macro_line_edit.editingFinished.connect(partial(self.validateName, editor, index))

        # 'DELETE MACRO' button
        editor.macro_delete_button.setObjectName(f"macro_{row}_delete_button")
        editor.macro_delete_button.clicked.connect(partial(
            index.model().removeRows,
            index=persistent_index,
            count=1,
            parent=QModelIndex()
        ))

        return editor

    def setEditorData(self, editor, index):

        text = index.data(Qt.ItemDataRole.EditRole)
        editor.macro_line_edit.setText(text)

        return text

    def updateEditorGeometry(self, editor, option, index):

        editor_rect = QRect(
            0,
            ROW_HEIGHT * index.row(),
            editor.parentWidget().width(),
            ROW_HEIGHT
        )
        editor.setGeometry(editor_rect)

        return editor_rect

    def setModelData(self, editor, model, index):

        text = editor.macro_line_edit.text()
        with SDHistoryUtils.UndoGroup(
                "{} '{}'".format(HISTORY_ENTRY_LABEL_EDIT, index.data(Qt.ItemDataRole.DisplayRole))
        ):
            model.setData(index=index, value=text, role=Qt.ItemDataRole.EditRole)

        return text

    def validateName(self, editor: QObject, index: QModelIndex) -> None:

        text: str = editor.macro_line_edit.text()
        macro_names: list[str] = index.model().get_macro_names()

        if (not text) or text.isspace():
            self.result_signal.emit(False, 0)
            editor.macro_line_edit.setText(index.data(Qt.ItemDataRole.DisplayRole))

        elif text in macro_names:
            self.result_signal.emit(False, 1)
            editor.macro_line_edit.setText(index.data(Qt.ItemDataRole.DisplayRole))

        else:
            self.result_signal.emit(True, 0)
            self.commitData.emit(editor)


class MacroEditor(QtWidgets.QFrame):

    def __init__(self, parent: QtWidgets.QWidget):

        super(MacroEditor, self).__init__(parent=parent)

        self.frame_layout = QtWidgets.QHBoxLayout()
        self.frame_layout.setContentsMargins(0, 0, 0, 0)

        # 'MOVE UP' button
        self.move_up_button = QtWidgets.QToolButton(parent=parent)
        self.move_up_button.setIcon(icon_factory("item_move_up.svg"))
        self.move_up_button.setToolTip(EDIT_DIALOG_MOVE_UP_TOOLTIP)
        self.move_up_button.setGeometry(0, 0, MACRO_EDITOR_BUTTON_WIDTH, ROW_HEIGHT)
        self.move_up_button.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.frame_layout.addWidget(self.move_up_button)

        # 'MOVE DOWN' button
        self.move_down_button = QtWidgets.QToolButton(parent=parent)
        self.move_down_button.setIcon(icon_factory("item_move_down.svg"))
        self.move_down_button.setToolTip(EDIT_DIALOG_MOVE_DOWN_TOOLTIP)
        self.move_down_button.setGeometry(0, 0, MACRO_EDITOR_BUTTON_WIDTH, ROW_HEIGHT)
        self.move_down_button.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.frame_layout.addWidget(self.move_down_button)

        # 'MACRO NAME' line edit
        self.macro_line_edit = QtWidgets.QLineEdit(parent=self)
        self.frame_layout.addWidget(self.macro_line_edit)

        # 'DELETE' button
        self.macro_delete_button = QToolButton(parent=parent)
        self.macro_delete_button.setIcon(icon_factory("item_delete.svg"))
        self.macro_delete_button.setToolTip(EDIT_DIALOG_DELETE_TOOLTIP)
        self.macro_delete_button.setGeometry(0, 0, MACRO_EDITOR_BUTTON_WIDTH, ROW_HEIGHT)
        self.macro_delete_button.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.frame_layout.addWidget(self.macro_delete_button)

        self.setLayout(self.frame_layout)

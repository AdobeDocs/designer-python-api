##########################################################################
# ADOBE CONFIDENTIAL
# ___________________
#  Copyright 2010-2024 Adobe
#  All Rights Reserved.
# * NOTICE:  Adobe permits you to use, modify, and distribute this file in
# accordance with the terms of the Adobe license agreement accompanying it.
# If you have received this file from a source other than Adobe,
# then your use, modification, or distribution of it requires the prior
# written permission of Adobe.
##########################################################################
#
# This module defines the NodeMacroToolbar class, which is used to build the object
# that should be added to the Graph View toolbar.

from sd.api.qtforpythonuimgrwrapper import QtForPythonUIMgrWrapper
from sd.api.sdpluginmgr import SDPluginMgr
from sd.api.sdhistoryutils import SDHistoryUtils
from sd.api.sbs.sdsbscompgraph import SDSBSCompGraph
from PySide6.QtWidgets import QToolBar
from PySide6.QtCore import Qt, QModelIndex
from .ui import create_toolbar_button, info_dialog_factory, TOOLTIP_STYLE
from .ui import SaveMacroDialog, EditMacrosDialog
from .node_macro_model import MACRO_MODELS, CUSTOM_ROLES
from .node_macro_views import MacrosToolbarView
from .utilities import *

from typing import Optional

SUPPORTED_PKG_FILETYPES = [".sbs", ".sbsar"]


class NodeMacrosToolbar(QToolBar):
    # TODO Add an option to list toolbar macros as a drop down menu

    supported_types: dict[str] = {
        "SDSBSCompGraph": "SDSBSCompNode",
        "SDSBSFunctionGraph": "SDSBSFunctionNode"
    }

    def __init__(
        self,
        ui_mgr: QtForPythonUIMgrWrapper,
        graph: SDGraph,
        pkg_mgr: SDPackageMgr,
        plugin_mgr: SDPluginMgr,
        graph_view_id: int
    ):

        self.__ui_mgr: QtForPythonUIMgrWrapper = ui_mgr
        self.__pkg_mgr: SDPackageMgr = pkg_mgr

        self.graph_view_id: int = graph_view_id
        self.graph_view = self.__ui_mgr.getGraphView(self.graph_view_id)
        self.graph_viewport: QGraphicsView = self.__get_viewport()

        self.main_window = self.__ui_mgr.getMainWindow()
        super(NodeMacrosToolbar, self).__init__(parent=self.main_window)

        # Dictionary of macros in toolbar:
        # {
        #     "macro name": {
        #         "name": macro_name,
        #         "sanitized_name": sanitized_name,
        #         "description": macro_description,
        #         "filepath": filepath
        #     }
        # }

        self.graph = graph
        self.graph_type = self.graph.getClassName()
        self.collection_path = path.join(
            plugin_mgr.getUserPluginsDir(),
            "node_macros",
            self.graph_type
        )

        self.setObjectName("node_macros_toolbar")

        self.__action_add_macro = create_toolbar_button(
            toolbar=self,
            object_name="add_macro_button",
            tooltip=BUTTON_TOOLTIP_SAVE,
            icon_filename="add_macro.svg"
        )
        self.__action_add_macro.triggered.connect(self.__on_save_macro)

        self.__action_edit_macros = create_toolbar_button(
            toolbar=self,
            object_name="edit_macros_button",
            tooltip=BUTTON_TOOLTIP_EDIT,
            icon_filename="macro_settings.svg"
        )
        self.__action_edit_macros.triggered.connect(self.on_edit_macros)

        LOGGER.info(INFO_TOOLBAR_BUTTONS_CREATED)

        self.__load_macros()

    def __get_viewport(self) -> Optional[QGraphicsView]:

        for child in self.graph_view.findChildren(QGraphicsView):
            LOGGER.debug(INFO_FOUND_QGRAPHICSVIEW.format(self.graph_view_id, child))
            return child

        LOGGER.error(ERROR_NOT_FOUND_QGRAPHICSVIEW.format(self.graph_view_id))
        raise Exception("QGraphicsView not found")

    def __load_macros(self) -> None:

        try:
            self.macros_view = MacrosToolbarView(parent=self)
            self.macros_view.setModel(MACRO_MODELS[self.graph_type])
            self.macros_view.setStyleSheet(TOOLTIP_STYLE)
            self.addWidget(self.macros_view)
            self.macros_view.clicked.connect(self.on_place_macro)

        except Exception as ex:
            LOGGER.error(ERROR_LOAD_MACROS_FAIL.format(type(ex).__name__, ex.args))
            fail_dialog = info_dialog_factory(
                parent=self.main_window,
                text=WARNING_MACROS_NOT_LOADED
            )
            fail_dialog.show()

    def __on_save_macro(self) -> None:

        node_selection = self.__ui_mgr.getGraphSelectedNodesFromGraphViewID(self.graph_view_id)
        helpers_selection = self.__ui_mgr.getGraphSelectedObjectsFromGraphViewID(self.graph_view_id)

        if node_selection or helpers_selection:
            save_macro_dialog = SaveMacroDialog(
                node_macros_toolbar=self,
                macros_names=MACRO_MODELS[self.graph_type].get_macro_names()
            )

            if save_macro_dialog.exec_():
                macro_name: str = save_macro_dialog.macro_name_input.text()
                macro_description: str = save_macro_dialog.macro_description_input.toPlainText()
                filepath = self.__copy_macro_to_new_pkg(
                    macro_index=MACRO_MODELS[self.graph_type].rowCount(),
                    macro_name=macro_name,
                    macro_description=macro_description,
                    selected_nodes_id=node_selection,
                    selected_helpers=helpers_selection
                )
                if filepath:
                    new_macro_row: int = MACRO_MODELS[self.graph_type].rowCount()
                    MACRO_MODELS[self.graph_type].insertRows(new_macro_row, 1, QModelIndex())
                    new_macro_index: QModelIndex = MACRO_MODELS[self.graph_type].index(new_macro_row, 0, QModelIndex())
                    sanitized_name = sanitize_filename(macro_name)
                    # Save macro data in macros model
                    MACRO_MODELS[self.graph_type].setData(
                        new_macro_index,
                        macro_name,
                        Qt.ItemDataRole.DisplayRole
                    )
                    MACRO_MODELS[self.graph_type].setData(
                        new_macro_index,
                        macro_description,
                        Qt.ItemDataRole.ToolTipRole
                    )
                    MACRO_MODELS[self.graph_type].setData(
                        new_macro_index,
                        filepath,
                        CUSTOM_ROLES["Filepath"]
                    )
                    MACRO_MODELS[self.graph_type].setData(
                        new_macro_index,
                        sanitized_name,
                        CUSTOM_ROLES["SanitizedName"]
                    )
                    LOGGER.info(INFO_MACRO_SAVED.format(macro_name, filepath))
                else:
                    fail_dialog = info_dialog_factory(
                        parent=self.main_window,
                        text=WARNING_MACRO_NOT_SAVED
                    )
                    fail_dialog.show()
        else:
            fail_dialog = info_dialog_factory(
                parent=self.main_window,
                text=WARNING_SAVE_NO_SELECTION
            )
            fail_dialog.show()

    def __copy_macro_to_new_pkg(
        self,
        macro_index: int,
        macro_name: str,
        macro_description: str,
        selected_nodes_id: SDArray[SDNode],
        selected_helpers: SDArray[SDGraphObject]
    ) -> str:

        new_pkg: sd.api.sdpackage.SDPackage = self.__pkg_mgr.newUserPackage()
        LOGGER.debug(f"Macro package created {new_pkg}")

        macro_graph: Optional[SDGraph] = None

        if isinstance(self.graph, SDSBSCompGraph):
            macro_graph = SDSBSCompGraph.sNew(new_pkg)
        elif isinstance(self.graph, SDSBSFunctionGraph):
            macro_graph = SDSBSFunctionGraph.sNew(new_pkg)
        LOGGER.debug(f"Macro graph created: {macro_graph}")

        # Use input macro name as label
        macro_graph.setAnnotationPropertyValueFromId(
            sdAnnotationPropertyId="label",
            sdValue=SDValueString.sNew(macro_name)
        )
        LOGGER.debug(f"Macro graph Label: {macro_name}")

        # Use input macro description as description
        macro_graph.setAnnotationPropertyValueFromId(
            sdAnnotationPropertyId="description",
            sdValue=SDValueString.sNew(macro_description)
        )
        LOGGER.debug(f"Macro graph Description: {macro_description}")

        macro_id = sanitize_filename(macro_name)
        macro_graph.setIdentifier(macro_id)
        LOGGER.debug(f"Macro graph ID: {macro_id}")

        macro_graph_output_ids = [node.getIdentifier() for node in self.graph.getOutputNodes()]
        LOGGER.debug(f"Macro graph Outputs IDs: {macro_graph_output_ids}")

        # Copy selected nodes to macro graph
        try:
            copy_selection_to_graph(
                selected_nodes=selected_nodes_id,
                output_nodes_id=macro_graph_output_ids,
                selected_helpers=selected_helpers,
                target_graph=macro_graph
            )
        except Exception as ex:
            LOGGER.error(ERROR_COPY_TO_GRAPH_FAIL.format(type(ex).__name__, ex.args))
            return ""

        # Use sanitized macro name as package filename
        macro_filename = f"{str(macro_index)}_{sanitize_filename(macro_name)}.sbs"

        pkg_filepath = path.join(self.collection_path, macro_filename)

        # Save macro package
        try:
            self.__pkg_mgr.savePackageAs(new_pkg, pkg_filepath)
            self.__pkg_mgr.unloadUserPackage(new_pkg)
        except Exception as ex:
            LOGGER.error(ERROR_SAVE_MACRO_FAIL.format(type(ex).__name__, ex.args))
            return ""

        return pkg_filepath

    def on_edit_macros(self) -> None:

        edit_macros_dialog = EditMacrosDialog(parent=self, graph_type=self.graph_type)
        edit_macros_dialog.show()
        edit_macros_dialog.setFocus()

    # TODO Support auto-connection of macros in the simplest case: one output in selection, one input in macro.
    def on_place_macro(self, index: QModelIndex) -> None:

        macro_name = index.data(Qt.ItemDataRole.DisplayRole)

        with SDHistoryUtils.UndoGroup(
                HISTORY_ENTRY_LABEL_PLACE +
                " '{}'".format(macro_name)
        ):

            macro_pkg_path: str = index.data(CUSTOM_ROLES["Filepath"])
            macro_pkg = self.__pkg_mgr.loadUserPackage(
                macro_pkg_path,
                updatePackages=True,
                reloadIfModified=True
            )

            macro_graph_identifier: str = index.data(CUSTOM_ROLES["SanitizedName"])
            macro_graph: Optional[SDGraph] = macro_pkg.findResourceFromUrl(macro_graph_identifier)
            LOGGER.debug(INFO_LOADED_GRAPH.format(macro_graph_identifier, macro_pkg_path))

            macro_graph_output_id = [node.getIdentifier() for node in macro_graph.getOutputNodes()]

            try:
                if isinstance(macro_graph, SDGraph):
                    # Copy nodes from macro graph
                    copy_selection_to_graph(
                        selected_nodes=macro_graph.getNodes(),
                        output_nodes_id=macro_graph_output_id,
                        selected_helpers=macro_graph.getGraphObjects(),
                        target_graph=self.graph,
                        target_graph_viewport=self.graph_viewport,
                        use_viewport=True
                    )
                self.__pkg_mgr.unloadUserPackage(macro_pkg)
                LOGGER.info(INFO_PLACED_MACRO.format(macro_name))
            except Exception as ex:
                LOGGER.error(ERROR_PLACED_MACRO_FAIL.format(type(ex).__name__, ex.args))
                fail_dialog = info_dialog_factory(
                    parent=self.main_window,
                    text=WARNING_MACRO_NOT_PLACED
                )
                fail_dialog.show()

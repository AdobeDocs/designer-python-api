##########################################################################
# ADOBE CONFIDENTIAL
# ___________________
#  Copyright 2010-2024 Adobe
#  All Rights Reserved.
# * NOTICE:  Adobe permits you to use, modify, and distribute this file in
# accordance with the terms of the Adobe license agreement accompanying it.
# If you have received this file from a source other than Adobe,
# then your use, modification, or distribution of it requires the prior
# written permission of Adobe.
##########################################################################
#
# NODE MACROS PLUGIN FOR SUBSTANCE 3D DESIGNER
#
# This plugin adds a toolbar in the Graph View.
# The toolbar offers actions to save nodes as macros.
# These macros can then be recreated in a single click.

from os import listdir
from functools import partial
from .node_macro_toolbar import *
from .node_macro_model import NodeMacroModel, MACRO_MODELS
from .ui import icon_factory
from .ui_strings import *

CALLBACK_ID = None
callback_id_list = []

SUPPORTED_PKG_FILETYPES: set[str] = {".sbs", ".sbsar"}
SUPPORTED_GRAPHS: set[str] = {"SDSBSCompGraph", "SDSBSFunctionGraph"}

CTX = sd.getContext()
APP = CTX.getSDApplication()
UI_MGR: QtForPythonUIMgrWrapper = APP.getQtForPythonUIMgr()
PKG_MGR: SDPackageMgr = APP.getPackageMgr()
PLUGIN_MGR: SDPluginMgr = APP.getPluginMgr()


def initialise_macro_model(
    graph_type: str,
    plugin_mgr: SDPluginMgr,
    pkg_mgr: SDPackageMgr
) -> NodeMacroModel:

    macros: list[dict] = []
    macro_collection_path = path.join(plugin_mgr.getUserPluginsDir(), "node_macros", graph_type)

    if path.isdir(macro_collection_path):

        with (SDHistoryUtils.UndoGroup(HISTORY_ENTRY_LABEL_LOAD)):

            macro_collection_filepaths: list[str] = [
                path.join(macro_collection_path, filename)
                for filename
                in listdir(macro_collection_path)
                if path.splitext(filename)[1] in SUPPORTED_PKG_FILETYPES
            ]
            LOGGER.debug(INFO_INIT_COLLECTION_FILEPATHS.format(macro_collection_path))

            for macro_filepath in sorted(macro_collection_filepaths):
                try:
                    macro_pkg = pkg_mgr.loadUserPackage(macro_filepath)
                    macro_graph = macro_pkg.getChildrenResources(isRecursive=False)[0]
                    macro_name: str = macro_graph.getAnnotationPropertyValueFromId("label").get()
                    macro_description: str = macro_graph.getAnnotationPropertyValueFromId("description").get()

                    macros.append({
                        "name": macro_name,
                        "description": macro_description,
                        "sanitized_name": path.basename(macro_filepath).split(".")[0].partition("_")[-1],
                        "filepath": macro_filepath,
                    })

                    pkg_mgr.unloadUserPackage(macro_pkg)
                except Exception as ex:
                    LOGGER.error(ERROR_INIT_MACRO_FAIL.format(macro_filepath, type(ex).__name__, ex.args))
                    fail_dialog = info_dialog_factory(
                        parent=UI_MGR.getMainWindow(),
                        text=WARNING_MACRO_NOT_LOADED_FROM_CATALOGUE
                    )
                    fail_dialog.show()

    return NodeMacroModel(macros=macros, package_mgr=pkg_mgr)


def on_new_graph_view_created(
    graph_view_id: int,
    ui_mgr: QtForPythonUIMgrWrapper,
    pkg_mgr: SDPackageMgr,
    plugin_mgr: SDPluginMgr
) -> None:

    graph: SDGraph = ui_mgr.getGraphFromGraphViewID(graph_view_id)

    if graph.getClassName() in node_macro_toolbar.NodeMacrosToolbar.supported_types:
        macros_toolbar = node_macro_toolbar.NodeMacrosToolbar(
            graph=graph,
            ui_mgr=ui_mgr,
            pkg_mgr=pkg_mgr,
            plugin_mgr=plugin_mgr,
            graph_view_id=graph_view_id
        )
        ui_mgr.addToolbarToGraphView(
            graphViewID=graph_view_id,
            toolbar=macros_toolbar,
            icon=icon_factory("macro.svg"),
            tooltip="Node macros"
        )
    else:
        LOGGER.warning(WARNING_UNSUPPORTED_GRAPH_TYPE)


def initializeSDPlugin() -> None:

    global CALLBACK_ID, callback_id_list

    # Register callback when graph views are created
    CALLBACK_ID = UI_MGR.registerGraphViewCreatedCallback(partial(
        on_new_graph_view_created,
        ui_mgr=UI_MGR,
        pkg_mgr=PKG_MGR,
        plugin_mgr=PLUGIN_MGR
    ))
    callback_id_list.append(CALLBACK_ID)

    for graph_type in SUPPORTED_GRAPHS:
        MACRO_MODELS[graph_type] = initialise_macro_model(
            graph_type=graph_type,
            plugin_mgr=PLUGIN_MGR,
            pkg_mgr=PKG_MGR
        )

    LOGGER.debug(INFO_INIT_ACTIONS_REGISTERED)


def uninitializeSDPlugin() -> None:

    global callback_id_list

    LOGGER.debug(INFO_INIT_ACTIONS_UNREGISTERED)

    # Unregister all callbacks
    for callback_id in callback_id_list:
        UI_MGR.unregisterCallback(callback_id)

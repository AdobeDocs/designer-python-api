##########################################################################
# ADOBE CONFIDENTIAL
# ___________________
#  Copyright 2010-2024 Adobe
#  All Rights Reserved.
# * NOTICE:  Adobe permits you to use, modify, and distribute this file in
# accordance with the terms of the Adobe license agreement accompanying it.
# If you have received this file from a source other than Adobe,
# then your use, modification, or distribution of it requires the prior
# written permission of Adobe.
##########################################################################

from PySide6 import QtWidgets
from PySide6.QtWidgets import QMainWindow, QDialog, QToolBar, QMessageBox
from PySide6.QtWidgets import QLabel, QPushButton, QDialogButtonBox, QHBoxLayout
from PySide6.QtGui import QAction
from .node_macro_views import MacrosEditView, MacroEditDelegate, MacroEditor
from .node_macro_model import MACRO_MODELS, QModelIndex
from .ui_strings import *
from .utilities import icon_factory

WARNING_COLOR = "#FAFA64"

TOOLTIP_STYLE = """QToolTip {
      background: #333333;
      border-color: #666666;
      border-style: solid;
      border-width: 1px;
      padding: 6px;
      max-width: 600px;
      color: #cccccc;
    }"""


def create_toolbar_button(
    toolbar: QToolBar,
    object_name: str,
    tooltip: str,
    icon_filename: str,
    text: str = ""
) -> QAction:
    """
    Adds a QAction to the specified toolbar.
    If 'icon_filename' is set to an empty string, the 'text' is used as a label.
    :param toolbar: The toolbar that should host the QAction.
    :param object_name: The QAction's object name.
    :param tooltip: The QAction's tooltip.
    :param icon_filename: The filename for the QAction's icon, which should be located in the 'icons' folder.
    :param text: The button's label. Default is an empty string.
    :return: The created QAction.
    """

    button = QAction(parent=toolbar)
    if icon_filename:
        button.setIcon(icon_factory(icon_filename=icon_filename))
    else:
        button.setText(text)
    button.setToolTip(tooltip)
    button.setObjectName(object_name)
    toolbar.addAction(button)
    toolbar.setStyleSheet(TOOLTIP_STYLE)

    return button


def info_dialog_factory(parent: QMainWindow, text: str) -> QMessageBox:

    dialog = QMessageBox(parent=parent)
    dialog.setWindowTitle(INFO_DIALOG_TITLE)
    dialog.setText(text)
    dialog.setModal(True)
    dialog.setFocus()
    dialog.addButton(QMessageBox.StandardButton.Ok)
    dialog.setStyleSheet(TOOLTIP_STYLE)

    return dialog


def edit_macros_dialog_factory(parent: QMainWindow, macros: list[dict]) -> QDialog:

    # TODO Add description field
    dialog = QDialog(parent=parent)
    dialog.setObjectName("edit-macros-dialog")
    dialog.setWindowTitle(EDIT_DIALOG_TITLE)
    dialog.setModal(True)
    dialog.setStyleSheet(TOOLTIP_STYLE)

    dialog_layout = QtWidgets.QVBoxLayout()

    # Macros list widget
    macros_list_widget = QtWidgets.QListWidget(parent=dialog)
    macros_list_widget.setModel(MACRO_MODELS["SDSBSCompGraph"])
    macros_list_widget.setObjectName("edit-macros-dialog-list")

    for macro in macros:
        macro_edit_widget = MacroEditor(parent=dialog)
        macro_edit_widget.macro_line_edit.setObjectName(f'line_edit_{macro["sanitized_name"]}')
        macro_edit_widget.macro_delete_button.setObjectName(f'delete_button_{macro["sanitized_name"]}')
        macros_list_widget.setIndexWidget(
            macros_list_widget.model().index(macro, 0, QModelIndex()),
            macro_edit_widget
        )
    macros_list_widget.setDragDropMode(QtWidgets.QAbstractItemView.DragDropMode.InternalMove)

    # Buttons
    button_layout = QHBoxLayout()
    ok_button = QPushButton(parent=dialog, text=SAVE_DIALOG_OK)
    ok_button.setObjectName("edit-macros-dialog-ok-button")
    button_layout.addWidget(ok_button)
    cancel_button = QPushButton(parent=dialog, text=SAVE_DIALOG_CANCEL)
    cancel_button.setObjectName("edit-macros-dialog-cancel-button")
    button_layout.addWidget(cancel_button)

    # Populate main layout
    dialog_layout.addWidget(macros_list_widget)
    dialog_layout.addLayout(button_layout)
    dialog.setLayout(dialog_layout)

    return dialog


class EditMacrosDialog(QDialog):

    def __init__(self, parent: QToolBar, graph_type: str):

        super(EditMacrosDialog, self).__init__(parent=parent)
        self.parent = parent
        self.setMinimumSize(200, 200)

        self.setWindowTitle(EDIT_DIALOG_TITLE)
        self.layout = QtWidgets.QVBoxLayout()

        # Build list view and delegate
        self.model = MACRO_MODELS[graph_type]
        self.list_view = MacrosEditView(parent=self)
        self.list_view.setModel(self.model)
        self.item_delegate = MacroEditDelegate()
        self.list_view.setItemDelegate(self.item_delegate)
        self.layout.addWidget(self.list_view)

        # Open persistent editors for delegates
        for row in range(self.model.rowCount()):
            self.list_view.openPersistentEditor(self.model.index(row=row, column=0, parent=QModelIndex()))

        # Add validation label
        self.validation_label = self.build_validation_label()
        self.item_delegate.result_signal.connect(self.update_validation_label)

        # Add 'CLOSE' button
        self.build_close_button()

        self.setLayout(self.layout)

    def build_validation_label(self) -> QLabel:

        validation_label = QLabel()
        validation_label.setContentsMargins(0, 5, 0, 5)
        validation_label.setVisible(False)
        self.layout.addWidget(validation_label)

        return validation_label

    def update_validation_label(self, accepted: bool, result_code: int = 0) -> bool:

        if accepted:
            self.validation_label.setVisible(False)
            return True

        elif result_code == 0:
            self.validation_label.setText(f'<font color="{WARNING_COLOR}">{EDIT_WARNING_EMPTY}</font>')
            self.validation_label.setVisible(True)
            return False

        elif result_code == 1:
            self.validation_label.setText(f'<font color="{WARNING_COLOR}">{EDIT_WARNING_EXISTS}</font>')
            self.validation_label.setVisible(True)
            return False

    def build_close_button(self) -> None:

        close_button = QPushButton(parent=self, text=EDIT_DIALOG_CLOSE)
        close_button.setObjectName("edit-macros-dialog-close-button")
        close_button.clicked.connect(self.close)
        self.layout.addWidget(close_button)


class SaveMacroDialog(QDialog):

    def __init__(self, node_macros_toolbar: QToolBar, macros_names: list[dict]):

        self.parent = node_macros_toolbar
        super(SaveMacroDialog, self).__init__(parent=self.parent)

        self.setWindowTitle(SAVE_DIALOG_TITLE)

        self.macros_names = macros_names

        self.form_layout = QtWidgets.QFormLayout()

        self.macro_name_input = self.macro_name_setting()
        self.macro_name_validation_label = self.validation_label()

        self.macro_description_input = self.setup_macro_description_setting()

        self.buttons = self.setup_dialog_buttons()
        self.buttons.button(QDialogButtonBox.StandardButton.Ok).setEnabled(False)

        self.setLayout(self.form_layout)

    def macro_name_setting(self) -> QtWidgets.QLineEdit:

        macro_name_input = QtWidgets.QLineEdit(parent=self)
        macro_name_input.setObjectName("macro_name_input")
        macro_name_input.editingFinished.connect(self.validate_macro_name)

        macro_name_label = QLabel(f"{SAVE_FIELD_NAME}:", parent=self)
        macro_name_label.setObjectName("macro_name_label")
        self.form_layout.addRow(macro_name_label, macro_name_input)

        return macro_name_input

    def setup_macro_description_setting(self) -> QtWidgets.QPlainTextEdit:

        macro_desc_input = QtWidgets.QPlainTextEdit(parent=self)
        macro_desc_input.setObjectName("macro_description_input")
        macro_desc_input.rect().setHeight(60)
        macro_desc_label = QLabel(f"{SAVE_FIELD_DESCRIPTION}:", parent=self)
        macro_desc_label.setObjectName("macro_description_label")
        self.form_layout.addRow(macro_desc_label, macro_desc_input)

        return macro_desc_input

    def setup_dialog_buttons(self) -> QDialogButtonBox:

        # 'Ok' and 'Cancel' buttons
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        self.form_layout.addRow(buttons)

        return buttons

    def validation_label(self) -> QLabel:

        validation_label = QLabel()
        self.form_layout.addRow(QtWidgets.QFrame(), validation_label)

        return validation_label

    def validate_macro_name(self):

        name = self.macro_name_input.text()

        if name and not name.isspace():
            if name not in self.macros_names:
                self.buttons.button(QDialogButtonBox.StandardButton.Ok).setEnabled(True)
                self.macro_name_validation_label.setText("")
            else:
                self.macro_name_validation_label.setText(f'<font color="{WARNING_COLOR}">{SAVE_WARNING_EXISTS}</font>')
                self.buttons.button(QDialogButtonBox.StandardButton.Ok).setEnabled(False)
        else:
            self.macro_name_validation_label.setText(f'<font color="{WARNING_COLOR}">{SAVE_WARNING_EMPTY}</font>')
            self.buttons.button(QDialogButtonBox.StandardButton.Ok).setEnabled(False)

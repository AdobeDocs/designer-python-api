##########################################################################
# ADOBE CONFIDENTIAL
# ___________________
#  Copyright 2010-2024 Adobe
#  All Rights Reserved.
# * NOTICE:  Adobe permits you to use, modify, and distribute this file in
# accordance with the terms of the Adobe license agreement accompanying it.
# If you have received this file from a source other than Adobe,
# then your use, modification, or distribution of it requires the prior
# written permission of Adobe.
##########################################################################

import os
from typing import cast, List, Optional

from sd.api.sdpackagemgr import SDPackageMgr
from PySide6.QtCore import Qt, QAbstractListModel, QModelIndex, QPersistentModelIndex
from PySide6.QtCore import QMimeData, QByteArray, QDataStream, QIODevice
from .utilities import sanitize_filename, edit_macro_data

MACRO_MODELS: dict = {}
CUSTOM_ROLES: dict = {
    "Filepath": 1070,
    "SanitizedName": 1071
}


class NodeMacroModel(QAbstractListModel):

    # TODO Replace 'Move' buttons with drag-and-drop handles to reorder macros
    MACRO_MIMETYPE = "macro_dict"

    def __init__(self, macros: list[dict], package_mgr: SDPackageMgr, parent=None):

        super(NodeMacroModel, self).__init__(parent=parent)
        self.macros: list[dict] = macros
        self.package_mgr = package_mgr

    def flags(self, index) -> Qt.ItemFlags:

        if not index.isValid():
            return QAbstractListModel.flags(self, index)

        return Qt.ItemFlag.ItemIsEnabled  # | Qt.ItemIsSelectable | Qt.ItemIsDragEnabled | Qt.ItemIsDropEnabled

    def index(self, row, column=..., parent=...) -> QModelIndex:

        if row < 0 or row >= len(self.macros):
            return QModelIndex()

        return self.createIndex(row, column)

    def parent(self) -> QModelIndex:

        return QModelIndex()

    def row_from_macro_name(self, name: str) -> Optional[int]:

        for index, macro in enumerate(self.macros):
            if macro["name"] == name:
                return index

        return None

    def get_macro_names(self) -> list[str]:
        return [macro["name"] for macro in self.macros]

    def supportedDropActions(self):

        return Qt.DropAction.MoveAction

    # READ
    def data(self, index, role=...) -> Optional[str]:

        row = index.row()

        if role == Qt.ItemDataRole.DisplayRole:
            return self.macros[row]["name"]
        elif role == Qt.ItemDataRole.ToolTipRole:
            return self.macros[row]["description"]
        elif role == Qt.ItemDataRole.EditRole:
            return self.macros[row]["name"]
        elif role == CUSTOM_ROLES["Filepath"]:
            return self.macros[row]["filepath"]
        elif role == CUSTOM_ROLES["SanitizedName"]:
            return self.macros[row]["sanitized_name"]
        else:
            return None

    def rowCount(self, parent=...) -> int:

        return len(self.macros)

    # WRITE
    def setData(self, index, value, role=...) -> bool:

        if not index.isValid():
            return False

        row = index.row()

        # TODO Log macro edits, including exceptions
        if role == Qt.ItemDataRole.ToolTipRole:
            self.macros[row]["description"] = value

        elif role == Qt.ItemDataRole.DisplayRole:
            self.macros[row]["name"] = value

        elif role == CUSTOM_ROLES["Filepath"]:
            self.macros[row]["filepath"] = value

        elif role == CUSTOM_ROLES["SanitizedName"]:
            self.macros[row]["sanitized_name"] = value

        elif role == Qt.ItemDataRole.EditRole:  # Use only when editing macro
            old_macro: dict = self.macros[row].copy()
            self.macros[row]["name"] = value
            self.macros[row]["sanitized_name"] = sanitize_filename(value)
            self.macros[row]["filepath"] = os.path.join(
                os.path.split(self.macros[row]["filepath"])[0],
                f'{str(row)}_{self.macros[row]["sanitized_name"]}.sbs'
            )
            new_macro = self.macros[row]
            edit_macro_data(self.package_mgr, old_macro, new_macro)

        self.dataChanged.emit(index, index)

        return True

    # RESIZE

    def insertRows(self, row, count, parent=...) -> bool:

        if count <= 0:
            return False

        self.beginInsertRows(
            QModelIndex(),
            row,
            row + count - 1
        )
        for i in range(count):
            self.macros.insert(row + i, dict())
        self.endInsertRows()

        return True

    def removeRows(self, index, count, parent=...) -> bool:
        if count <= 0:
            return False

        row = index.row()
        self.beginRemoveRows(QModelIndex(), row, row + count - 1)
        for i in range(count):
            os.remove(self.macros[row + i]["filepath"])
            del self.macros[row + i]
        self.endRemoveRows()

        return True

    def moveRowHandler(self, index: QPersistentModelIndex, offset: int) -> bool:

        count = self.rowCount()
        source_row = index.row()
        target_row = source_row + offset

        if target_row == count:
            target_row = 0
        elif target_row == -1:
            target_row = count - 1

        if source_row == target_row:
            return False

        if source_row < target_row:
            target_row += 1

        parent = QModelIndex()
        self.beginMoveRows(parent, source_row, source_row, parent, target_row)
        moved_macro = self.macros[source_row]
        self.macros.insert(target_row, moved_macro)
        del self.macros[source_row if source_row < target_row else source_row + 1]
        self.endMoveRows()

        self.setData(
            self.index(source_row, 0, parent),
            self.macros[source_row]["name"],
            Qt.ItemDataRole.EditRole
        )
        # TODO Fix this so this is not needed anymore!
        if source_row < target_row:
            target_row -= 1
        self.setData(
            self.index(target_row, 0, parent),
            self.macros[target_row]["name"],
            Qt.ItemDataRole.EditRole
        )

        return True

    def mimeTypes(self) -> List[str]:
        types: List[str] = QAbstractListModel.mimeTypes(self)
        types.append(NodeMacroModel.MACRO_MIMETYPE)
        return types

    def canDropMimeData(
        self,
        data: QMimeData,
        action: Qt.DropAction,
        row: int,
        column: int,
        parent: QModelIndex
    ) -> bool:
        return action == Qt.DropAction.MoveAction and data.hasFormat(NodeMacroModel.MACRO_MIMETYPE)

    def mimeData(self, indexes: List[int]) -> QMimeData:
        data: QMimeData = QMimeData()
        data_serialised = QByteArray()
        stream = QDataStream(data, QIODevice.OpenModeFlag.WriteOnly)

        for index in indexes:
            index = cast(QModelIndex, index)
            if index.isValid():
                text: str = self.data(index, Qt.ItemDataRole.DisplayRole)
                stream.writeString(text)

        data.setData(NodeMacroModel.MACRO_MIMETYPE, data_serialised)
        return data

    def dropMimeData(
        self,
        data: QMimeData,
        action: Qt.DropAction,
        row: int,
        column: int,
        parent: QModelIndex
    ) -> bool:

        if not self.canDropMimeData(data, action, row, column, parent):
            return False

        if action == Qt.DropAction.IgnoreAction:
            return True

        pass
